#int
a=2*2; //square=
