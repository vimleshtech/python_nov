a =33
o =a*a
print(o)

a =40
b =a*a*a
print(b)

a =4
c =3.14*a*a
print(c)

a =4
c =2*3.14*a
print(c)
