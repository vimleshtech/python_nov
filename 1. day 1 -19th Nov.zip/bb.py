number=float(input("4.5:"))
square=4.5*4.5
print("The square of 4.5"))


