hs =89
es =90
ms =78

total = hs+es+ms

avg = total /3
print 'total score is :',total
print 'average score is ', avg
