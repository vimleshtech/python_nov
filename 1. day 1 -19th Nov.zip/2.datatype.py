#int
a =111
print(a)
print(type(a))

#float
f =444.3
print(type(f))

#boold
f =True
print(type(f))

#str
a ='shssgssh222'
print(type(a))

a ="skhshgsgs"
print(type(a))

#list
a =[1111,222,3333]
print(type(a))

#tuple
t =(111,222,3334)
print(type(t))


#dict
d ={'a':'alpha','b':'beta'}
print(type(d))

#set
s ={'dove','lux','dove'}
print(s)
print(type

number= float(input("4.5:"))
print("The square of 4.5"))
