print 'hello', # show output in console

a =11
b =44
c =a+b
print(c)

