
#int
"""
a = 111
print(a)
print(type(a))

#float 
a = 111.4444
print(a)
print(type(a))
"""

#str
a   =             '111'
print(a)
print(type(a))

#str
a = "111dfkdjhddfg"
print(a)
print(type(a))

#bool 
a = True
print(a)
print(type(a))

#list
a = [111,4333,33232,2,'sjhsjhgs']
print(a)
print(type(a))


#tuple 
a = (111,4333,33232,2,'sjhsjhgs')
print(a)
print(type(a))



#dict
a = {'a':'item1',"b":'item2','db':'database',1:'one'}
print(a)
print(type(a))

#set
a = {'item1','item2','item1'}
print(a)
print(type(a))









