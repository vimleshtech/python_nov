name = input('enter data :')

print(type(name))

print('your data is ',name)


###
nn = input('enter  data :')
print(type(nn))

nn = int(nn)  # convert from str to int
print(type(nn))

