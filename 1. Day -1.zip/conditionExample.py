sales =500
tax = 0

#if condition 
if sales>1000:
     tax = sales*.18  


total = sales+tax
print(total)

#if else
tax = 0
if sales>1000: # if match
     tax = sales*.18
     print('test')
else:  #if not match
     tax = sales*.05



total = sales+tax
print(total)

### show greater no. from three input
a =111
b =5
c =44

if a>b and a>c:
     print('a is greater')
elif b>a and b>c:
     print('b is greater')
else:
     print('c is greater')
     

#nested if
if a>b:
     if a>c:
          print('a is greater')
     else:
          print('b is greater')
else:
     if b>c:
          print('b is greater')
     else:
          print('c is greater')

          

##
a='abcd'
if a =='abc d':
     print('matched...')
else:
     print('not matched...')



     









     



     
     

     

     
     
